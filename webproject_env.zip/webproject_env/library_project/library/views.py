from django.contrib.auth import authenticate, login
from .forms import LoginForm,RegisterForm,BookForm
from .models import customr,Book
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            try:
                user = customr.objects.get(username=username)
                if user.check_password(password):  # Use check_password to validate
                    # Log the user in (use sessions or Django auth if applicable)
                    request.session['user_id'] = user.id  # Example using sessions
                    return redirect('all_books')
                else:
                    form.add_error(None, "Invalid username or password.")
            except customr.DoesNotExist:
                form.add_error(None, "Invalid username or password.")
    else:
        form = LoginForm()

    return render(request, "library/login.html", {"form": form})


def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            new_user = customr(username=username)
            new_user.set_password(password)  # Hash the password using set_password
            new_user.save()

            messages.success(request, "Account created successfully. Please log in.")
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, "library/register.html", {"form": form})

def logout_view(request):
    request.session.flush()  # Clears all session data
    return redirect('login')

def all_books(request):
    books = Book.objects.all()  # Retrieve all books from database
    return render(request, 'library/all_books.html', {'books': books})


def add_book_view(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Book added successfully.")
            return render(request, 'library/add_book.html', {'form': form})  # Stay on the same page
    else:
        form = BookForm()

    return render(request, 'library/add_book.html', {'form': form})


def book_update(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, f'Book "{book.title}" updated successfully.')
            return redirect('all_books')  # Redirect to the book detail page after updating
    else:
        form = BookForm(instance=book)
    return render(request, 'library/book_form.html', {'form': form})



def delete_book(request, pk):
    if request.method == 'POST':
        book = get_object_or_404(Book, pk=pk)
        book.delete()
        messages.success(request, "Book deleted successfully.")
    return redirect('all_books')