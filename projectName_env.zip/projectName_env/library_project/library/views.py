from django.contrib.auth import authenticate, login
from .forms import LoginForm,RegisterForm,BookForm

from .models import customr
from django.contrib import messages
from django.shortcuts import render, redirect


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')  # Redirect to the homepage or another page after login
            else:
                form.add_error(None, "Invalid username or password.")
    else:
        form = LoginForm()

    return render(request, "library/login.html", {"form": form})



def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            # Get the form data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # Create a new customr instance (consider hashing the password in a production setting)
            customr.objects.create(username=username, password=password)

            messages.success(request, "Account created successfully. Please log in.")
            return redirect('login')  # Redirect to login page after registration
    else:
        form = RegisterForm()

    return render(request, "library/register.html", {"form": form})




def add_book_view(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Book added successfully.")
            return redirect('add_book')  # Redirect back to the add book page or another page as desired
    else:
        form = BookForm()

    return render(request, 'library/add_book.html', {'form': form})

# Create your views here.
