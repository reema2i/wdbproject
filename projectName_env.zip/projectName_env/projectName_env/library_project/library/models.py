from django.db import models
from django.contrib.auth.hashers import make_password, check_password

class customr(models.Model):
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=100)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)
        self.save()

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return f"User(username='{self.username}', password='{self.password}')"

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    genre = models.CharField(max_length=100)
    reserved_by = models.ManyToManyField(customr, blank=True, related_name="reserved_books")

    def __str__(self):
        return f"Book(title='{self.title}', author='{self.author}', genre='{self.genre}')"


# Create your models here.
