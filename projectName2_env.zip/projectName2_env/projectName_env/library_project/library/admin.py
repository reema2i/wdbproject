from django.contrib import admin
from .models import customr,Book

admin.site.register(customr)
admin.site.register(Book)


# Register your models here.
